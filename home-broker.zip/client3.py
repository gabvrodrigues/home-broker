import random
from Pyro5.api import expose, Daemon, Proxy, config

config.COMMTIMEOUT = 0.5
homeBroker = Proxy("PYRONAME:home.broker.server")

class CallbackHandler(object):
    workdone = False
    end = False

    @expose
    def done(self, message):
        print(message)
        CallbackHandler.workdone = True

    @expose
    def finish(self, order):
        print("Até Logo!")
        CallbackHandler.end = True

def printMenu():
    print("-----------HOME BROKER-----------")
    print("1) Adicionar ação às minhas cotações")
    print("2) Remover ação às minhas cotações")
    print("3) Ver minha lista de cotações")
    print("4) Comprar ação")
    print("5) Vender ação")
    print("6) Ver minha carteira")
    

def menu():
    printMenu()
    option = input("Escolha: ").strip()

    if(option == "1"):
        code = input("Código: ").strip()
        print(homeBroker.addStockToQuoteList(code))
    elif(option == "2"):
        code = input("Código: ").strip()
        print(homeBroker.removeStockToQuoteList(code))
    elif(option == "3"):
        if(len(homeBroker.getQuoteList()) == 0):
            print("Nenhuma ação encontrada")
        else:
            for stock in homeBroker.getQuoteList():
                print("{0} - {1}".format(stock["code"], stock["price"]))
    elif(option == "4"):
        code = input("Código: ").strip()
        quantity = input("Quantidade: ").strip()
        price = input("Preço: ").strip()
        time = input("Tempo(s): ").strip()
        buyStock({"code": code, "quantity": quantity, "price": price, "time": time, "type": "buy"})
    elif(option == "5"):
        code = input("Código: ").strip()
        quantity = input("Quantidade: ").strip()
        price = input("Preço: ").strip()
        time = input("Tempo(s): ").strip()
        sellStock({"code": code, "quantity": quantity, "price": price, "time": time, "type": "sell"})

    elif(option == "6"):
        if(len(homeBroker.getMyStocks()) == 0):
            print("Nenhuma ação encontrada")
        else:
            for stock in homeBroker.getMyStocks():
                print("{0} - {1}".format(stock["code"], stock["price"]))
    menu()

def buyStock(order):
    with Daemon() as daemon1:
        # register our callback handler
        callback = CallbackHandler()
        daemon1.register(callback)

        # with Proxy("PYRONAME:home.broker.server") as homeBroker:
        worker = homeBroker.addBuyOrder(callback)  # provide our callback handler!
        worker.work(order)
        # menu()
        print("Ordem enviada com sucesso!")
        menu()

        daemon1.requestLoop(loopCondition=lambda: CallbackHandler.workdone != True)
        # print("done!")
        CallbackHandler.workdone = False
        menu()

def sellStock(order):
    with Daemon() as daemon2:
        # register our callback handler
        callback = CallbackHandler()
        daemon2.register(callback)

        # with Proxy("PYRONAME:home.broker.server") as homeBroker:
        worker = homeBroker.addSellOrder(callback)  # provide our callback handler!
        worker.work(order)
        # menu()
        print("Ordem enviada com sucesso!")
        menu()

        daemon2.requestLoop(loopCondition=lambda: CallbackHandler.workdone != True)
        # print("done!")
        CallbackHandler.workdone = False
        menu()


with Daemon() as daemon:
    # register our callback handler
    callback = CallbackHandler()
    daemon.register(callback)

    # contact the server and put it to work
    print("creating a bunch of workers")
    # with Proxy("PYRONAME:home.broker.server") as homeBroker:
    worker = homeBroker.addClient(callback)  # provide our callback handler!
    worker.createClient()
    print("waiting for all work complete...")
    menu()
    daemon.requestLoop(loopCondition=lambda: CallbackHandler.end != True)
    print("bye!")

    







